package com.zilogic.tictactoe;


public class Log {

	Logger logger = Logger.getLogger(getClass().toString());

	public Log() {

	}
}
